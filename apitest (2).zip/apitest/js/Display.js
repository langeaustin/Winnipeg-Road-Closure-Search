/*
function searchZone() {
        let input = document.getElementById('search').value.trim();
        if (input != "") {
            const fetchSomethingSearch = async () => {
                const response = await fetch('https://data.winnipeg.ca/resource/lane_closure.json?' +
                    `$where=primary_street LIKE '%${input}%'` +
                    '&$order=date_closed_from DESC' +
                    '&$limit=30')

                const json = await response.json()
                addRoutes(json)
                // console.log(json)
                return json
            }
        }
    } */
const fetchSomething = async  () => {
    const response = await fetch('https://data.winnipeg.ca/resource/lane_closure.json?' +
        '&$order=date_closed_from DESC' +
        '&$limit=30')
    const json = await response.json()
    addRoutes(json)
    // console.log(json)
    return json
    }

//fetchSomething()

console.log(fetchSomething())

function addRoutes(zones) {
    let table = document.getElementById('zone');
    // clearSearch(table);
    for (let zone of zones )
    {
        addZoneToTableRow(zone, table);
    }
}

function addZoneToTableRow(zone, table) {
    const row             = document.createElement('tr');
    const plowIdTd    = document.createElement('td');
    const plowZoneTd = document.createElement('td');
    const plowNumTd      = document.createElement('td');
    const shiftStartTd      = document.createElement('td');
    const shiftEndTd      = document.createElement('td');
    const snowBanTd      = document.createElement('td');

    plowIdTd.innerHTML = zone.primary_street;
    plowZoneTd.innerHTML = zone.cross_street;
    plowNumTd.innerHTML = zone.traffic_effect;
    shiftStartTd.innerHTML = zone.direction;
    shiftEndTd.innerHTML = zone.date_closed_from.substring(0,10);
    snowBanTd.innerHTML = zone.date_closed_to.substring(0,10);

    row.appendChild(plowIdTd);
    row.appendChild(plowZoneTd);
    row.appendChild(plowNumTd);
    row.appendChild(shiftStartTd);
    row.appendChild(shiftEndTd); 
    row.appendChild(snowBanTd);
    table.appendChild(row);

}

function loadApp() {
    let formElement = document.getElementById("searchbutton");


    if(formElement)
    {
        formElement.addEventListener('click', searchZone);
    }
}

loadApp()
