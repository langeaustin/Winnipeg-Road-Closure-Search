
function searchZone() {
    let input = document.getElementById('search').value.trim();
    if (input != "")
    {
    const apiUrl = 'https://data.winnipeg.ca/resource/gqmr-3iad.json?' +
        `$where=plow_zone LIKE '%${input}%'` +
        '&$order=shift_start DESC' +
        '&$limit=100';

    const encodedURL = encodeURI(apiUrl);

        fetch(encodedURL)
            .then(function(result) {
                return result.json(); // Promise for parsed JSON.
            })
            .then(function(retrieved) {
                addRoutes(retrieved);
            });
    }
}

function addRoutes(zones) {
    let table = document.getElementById('zone');
    clearSearch(table);
    for (let zone of zones )
    {
        addZoneToTableRow(zone, table);
    }

}

function clearSearch() {

    let rows = document.getElementById('zone');
    Array.from(rows.children).map(row => {
        row.remove();
    })

    console.log(rows);
}


function addZoneToTableRow(zone, table) {
    const row             = document.createElement('tr');
    const plowIdTd    = document.createElement('td');
    const plowZoneTd = document.createElement('td');
    const plowNumTd      = document.createElement('td');
    const shiftStartTd      = document.createElement('td');
    const shiftEndTd      = document.createElement('td');
    const snowBanTd      = document.createElement('td');

    plowIdTd.innerHTML = zone.id;
    plowZoneTd.innerHTML = zone.plow_zone;
    plowNumTd.innerHTML = zone.shift_number;
    shiftStartTd.innerHTML = zone.shift_start;
    shiftEndTd.innerHTML = zone.shift_end;
    snowBanTd.innerHTML = table.snow_ban_id;

    row.appendChild(plowIdTd);
    row.appendChild(plowZoneTd);
    row.appendChild(plowNumTd);
    row.appendChild(shiftStartTd);
    table.appendChild(row);
}



function loadApp() {
    let formElement = document.getElementById("searchbutton");


    if(formElement)
    {
        formElement.addEventListener('click', searchZone);
    }
}

loadApp();