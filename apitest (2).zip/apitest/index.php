<?php

 $apiUrl = file_get_contents('https://data.winnipeg.ca/resource/lane_closure.json?');

 json_decode($apiUrl);
 print_r($apiUrl);

?>