function searchZone() {
    let input = document.getElementById('search').value.trim();
    if (input != "")
    {
        const apiUrl = 'https://data.winnipeg.ca/resource/lane_closure.json?' +
            `$where=primary_street LIKE '%${input}%'` +
            '&$order=date_closed_from DESC' +
            '&$limit=100';

        const encodedURL = encodeURI(apiUrl);

        fetch(encodedURL)
            .then(function(result) {
                return result.json(); // Promise for parsed JSON.
            })
            .then(function(retrieved) {
                addRoutes(retrieved);
            });
    }
}

function addRoutes(zones) {
    let table = document.getElementById('zone');
    clearSearch(table);
    for (let zone of zones )
    {
        addZoneToTableRow(zone, table);
    }
}

function clearSearch() {

    let rows = document.getElementById('zone');
    Array.from(rows.children).map(row => {
        row.remove();
});

   console.log(rows);
}


function addZoneToTableRow(zone, table) {
    const row             = document.createElement('tr');
    const plowIdTd    = document.createElement('td');
    const plowZoneTd = document.createElement('td');
    const plowNumTd      = document.createElement('td');
    const shiftStartTd      = document.createElement('td');
    const shiftEndTd      = document.createElement('td');
    const snowBanTd      = document.createElement('td');

    plowIdTd.innerHTML = zone.primary_street;
    plowZoneTd.innerHTML = zone.cross_street;
    plowNumTd.innerHTML = zone.traffic_effect;
    shiftStartTd.innerHTML = zone.direction;
    shiftEndTd.innerHTML = zone.date_closed_from;
    snowBanTd.innerHTML = zone.date_closed_to;

    row.appendChild(plowIdTd);
    row.appendChild(plowZoneTd);
    row.appendChild(plowNumTd);
    row.appendChild(shiftStartTd);
    row.appendChild(shiftEndTd);
    row.appendChild(snowBanTd);
    table.appendChild(row);
}



function loadApp() {
    let formElement = document.getElementById("searchbutton");


    if(formElement)
    {
        formElement.addEventListener('click', searchZone);
    }
}

loadApp();